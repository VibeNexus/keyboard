package com.example.tkb

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TranslateIME : InputMethodService() {

    private val langs = listOf(
        "English" to "en", "Türkçe" to "tr", "Français" to "fr", "Español" to "es",
        "Deutsch" to "de", "Italiano" to "it", "Русский" to "ru", "中文" to "zh-CN",
        "日本語" to "ja", "한국어" to "ko", "हिन्दी" to "hi", "Português" to "pt"
    )
    private var li = 0
    private val buf = StringBuilder()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var info: TextView
    private lateinit var langBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, weight: Float = 1f, bg: Int = Color.parseColor("#3A3A3C"), onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(bg)
        b.textSize = 17f
        b.isAllCaps = false
        b.setPadding(0, 0, 0, 0)
        val lp = LinearLayout.LayoutParams(0, dp(46), weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        return r
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#1C1C1E"))
        root.setPadding(dp(3), dp(3), dp(3), dp(3))

        info = TextView(this)
        info.setTextColor(Color.parseColor("#9BE7C4"))
        info.textSize = 15f
        info.setPadding(dp(8), dp(4), dp(8), dp(4))
        info.visibility = View.GONE
        root.addView(info)

        val top = row()
        langBtn = btn("→ ${langs[li].first}", 1.4f, Color.parseColor("#0A84FF")) {
            li = (li + 1) % langs.size
            langBtn.text = "→ ${langs[li].first}"
        }
        top.addView(langBtn)
        top.addView(btn("ترجم", 1f, Color.parseColor("#1F7A5C")) { translateBuffer(false) })
        top.addView(btn("ترجم وأرسل", 1.4f, Color.parseColor("#1F7A5C")) { translateBuffer(true) })
        top.addView(btn("اقرأ 📋", 1f, Color.parseColor("#8E5AD7")) { translateClipboard() })
        root.addView(top)

        val rows = listOf(
            "ضصثقفغعهخحجد",
            "شسيبلاتنمكط",
            "ئءؤرىةوزظذ"
        )
        for (line in rows) {
            val r = row()
            for (ch in line) r.addView(btn(ch.toString()) { typeChar(ch.toString()) })
            root.addView(r)
        }
        val last = row()
        last.addView(btn("،", 1f) { typeChar("،") })
        last.addView(btn("؟", 1f) { typeChar("؟") })
        last.addView(btn("مسافة", 4f) { typeChar(" ") })
        last.addView(btn(".", 1f) { typeChar(".") })
        last.addView(btn("⌫", 1.4f, Color.parseColor("#636366")) { backspace() })
        root.addView(last)
        return root
    }

    private fun typeChar(c: String) {
        buf.append(c)
        currentInputConnection?.setComposingText(buf.toString(), 1)
    }

    private fun backspace() {
        if (buf.isNotEmpty()) {
            buf.deleteCharAt(buf.length - 1)
            if (buf.isEmpty()) currentInputConnection?.commitText("", 1)
            else currentInputConnection?.setComposingText(buf.toString(), 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun showInfo(t: String?) {
        if (t.isNullOrEmpty()) { info.visibility = View.GONE } else { info.text = t; info.visibility = View.VISIBLE }
    }

    private fun translateBuffer(send: Boolean) {
        val text = buf.toString().trim()
        if (text.isEmpty()) return
        showInfo("جاري الترجمة...")
        val target = langs[li].second
        Thread {
            val out = try { translate(text, "ar", target) } catch (e: Exception) { null }
            ui.post {
                if (out == null) { showInfo("تعذّرت الترجمة، تأكد من الإنترنت"); return@post }
                showInfo(null)
                val ic = currentInputConnection ?: return@post
                ic.setComposingText(out, 1)
                ic.finishComposingText()
                buf.clear()
                if (send) {
                    if (!sendDefaultEditorAction(true)) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                }
            }
        }.start()
    }

    private fun translateClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (text.isNullOrEmpty()) { showInfo("انسخ رسالة الأجنبي أولاً ثم اضغط اقرأ"); return }
        showInfo("جاري الترجمة...")
        Thread {
            val out = try { translate(text, "Autodetect", "ar") } catch (e: Exception) { null }
            ui.post { showInfo(out ?: "تعذّرت الترجمة، تأكد من الإنترنت") }
        }.start()
    }

    private fun translate(text: String, from: String, to: String): String {
        val url = URL("https://api.mymemory.translated.net/get?q=" +
                URLEncoder.encode(text, "UTF-8") + "&langpair=" + from + "|" + to)
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        val body = c.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(body).getJSONObject("responseData").getString("translatedText")
    }
}
